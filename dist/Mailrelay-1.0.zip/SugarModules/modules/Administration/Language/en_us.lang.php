<?php

$mod_strings['LBL_MAILRELAY'] = 'Mailrelay';
$mod_strings['LBL_MAILRELAY_DESC'] = 'Easily sync your SugarCRM users and contacts with Mailrelay';
$mod_strings['LBL_MAILRELAY_SETTINGS'] = 'Connection Settings';
$mod_strings['LBL_MAILRELAY_SETTINGS_DESC'] = 'Set the Mailrelay connection settings and other preferences';
$mod_strings['LBL_MAILRELAY_SYNC'] = 'Sync Users and Contacts';
$mod_strings['LBL_MAILRELAY_SYNC_DESC'] = 'Sync your SugarCRM users and contacts with Mailrelay manually';
